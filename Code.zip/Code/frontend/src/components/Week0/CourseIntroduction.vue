<template>
    <div>
      <h2>About the Course</h2>
      <div class="rating">
        <span class="stars">☆☆☆☆☆</span>
        <span class="rating-text">/ 5 (0 reviews)</span>
        <a href="#" class="submit-review">Submit a review</a>
      </div>
      <p>
        <strong>Course Instructor</strong><br />
        Sudarshan Iyengar,<br />
        Associate Professor,<br />
        Department of Computer Science & Engineering,<br />
        IIT Ropar
      </p>
      <p>
        <strong>Course Mentors</strong><br />
        1. Devineni Ramanjaneyulu (MTech, IIT Madras)<br />
        2. Karthik Thiagarajan (BTech, IIT Madras)
      </p>
      <p>
        <strong>Study Material:</strong> The primary study material for this course is the set of videos and assignments posted on the course page. The learners are advised to make the best use of the interaction sessions with the course support members in addition to the videos and assignments.
      </p>
    </div>
  </template>
  
  <script>
  export default {
    name: "CourseIntroduction",
  };
  </script>
  