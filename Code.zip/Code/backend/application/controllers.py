import os
import application.errors as errors
from flask import request, jsonify, make_response, send_file
from flask_restful import Resource
from application.models import User, Creator, Song, Playlist, Album, PlaylistSong
from application.token_validation import validate_jwt, generate_jwt
from application import db, api, app
from flask_bcrypt import Bcrypt
import json
from werkzeug.utils import secure_filename
import datetime
bcrypt = Bcrypt()

class Home(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Register(Resource):
    def post(self):
        try:
            data = request.get_json()
            username = data.get('username')
            password = data.get('password')
            email = data.get('email')
            mob = data.get('mob')
            name = data.get('name')
            role = data.get('role')
            if not (username and password and email and mob and name and role):
                return jsonify({'error': 'All fields are required', 'code': 400})

            hashed_password = bcrypt.generate_password_hash(password)
            existing_user = User.query.filter_by(username=username).first()
            if existing_user:
                return jsonify({'error': 'This username is already taken', 'code': 400})

            new_user = User(username=username, password=hashed_password, email=email, mob=mob, name=name, role=role, first_login_time=datetime.datetime.now())
            db.session.add(new_user)
            db.session.commit()
            if role == 'Creator':
                user=User.query.filter_by(username=username).first()
                c_id=user.id
                c=Creator(user_id=c_id)
                db.session.add(c)
                db.session.commit()
            return jsonify({'message': 'User created successfully', 'code': 201})

        except Exception as e:
            return jsonify({'error': 'Something went wrong', 'code': 500})

class Login(Resource):
    def get(self):
        try:
            auth=request.authorization
            print("inside login")
            if not auth or not auth.username or not auth.password:
                return make_response('Could not verify',401,{'WWW-Authenticate': 'Basic realm = "Login Required!"'} )
            username = auth.username
            password = auth.password
            if not (username and password):
                return jsonify({'error': 'Username and password are required', 'code': 400})

            user = User.query.filter_by(username=username).first()
            if ((not user) or (not bcrypt.check_password_hash(user.password, password))):
                return jsonify({'error':'Incorrect Username or Password!', 'code': 401})
            token = generate_jwt(self, id=user.id, role=user.role)
            user.prev_login = datetime.datetime.now()
            db.session.commit()
            print(token)
            return jsonify({'id': user.id, 'token': token, 'role': user.role, 'code': 200})

        except Exception as e:
            print(e)
            return jsonify({'error': 'Something went wrong', 'code': 500})

class Dashboard(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Study(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Downloads(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Forum(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Profile(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Content(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class CourseDocs(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Practice(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

class Graded(Resource):
    def post(self):
        return {"message": "Welcome to the API"}

api.add_resource(Home, "/")
api.add_resource(Login, "/login")
api.add_resource(Register, "/register")
api.add_resource(Dashboard, "/dashboard")
api.add_resource(Study, "/study")
api.add_resource(Downloads, "/downloads")
api.add_resource(Forum, "/forum")
api.add_resource(Profile, "/profile")
# api.add_resource(Deadlines, "/deadlines")
# api.add_resource(Announcements, "/announcements")
api.add_resource(Content, "/study/content")
api.add_resource(CourseDocs, "/study/course_docs")
api.add_resource(Practice, "/study/practice")
api.add_resource(Graded, "/study/graded")
# api.add_resource(Scores, "/scores")
# api.add_resource(Payments, "/profile/payments")
# api.add_resource(ATS, "/profile/ats")
# api.add_resource(Support, "/profile/support")