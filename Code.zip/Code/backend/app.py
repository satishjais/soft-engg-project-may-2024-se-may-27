from application import app

if __name__ == '__main__':
   app.run(debug=True, port=2000, host='0.0.0.0')